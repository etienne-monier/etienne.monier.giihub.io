%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Echantillonnage et quantification sur fichier son
% A. Picot - Fevrier 2015
%
% Fichier son: But not for me - Red Garland (1957)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all

cas='menu';
ok=1;
choix=0;

% Loading sound
%old [y, Fs, nbits] = wavread('BNFM2.wav');
[y, Fs] = audioread('BNFM2.wav');

%
while (ok)
    
    switch cas
        %Menu principal
        case 'menu'

            choix=menu({'Echantillonnage - Quantification','Traitement fichier sonore'},...
                'Ecouter','Echantillonner','Quantifier','Quitter');
            switch choix
                case 1
                    cas='listen';
                case 2
                    cas='ech';
                case 3
                    cas='quant';
                otherwise
                    ok=0;
            end
            
        % Ecoute    
        case 'listen'
            sound(y,Fs);
            cdata = imread('index.jpeg'); 
            msgbox('Extrait de "But not for me" par Red Garland (1957)','Ecoute','custom',cdata);
            cas='menu';
            
        % Echantillonnage    
        case 'ech'
            
            Fe=0;
            rep=2;
            out=0;
            
            while (((Fe<1)|(Fe>44100)|(rep<0)|(rep>1))&(out==0))
                %Menu
                prompt = {'Frequence echantillonnage (<44100Hz):','Filtre Anti-Repliement (0=Non - 1=Oui):'};
                dlg_title = 'Echantillonnage';
                num_lines = 1;
                def = {'22000','0'};
                answer = inputdlg(prompt,dlg_title,num_lines,def);
                if isempty(answer)
                    out=1;
                else
                    Fe=str2num(answer{1});
                    rep=str2num(answer{2});
                    if ((Fe<1)|(Fe>44100))
                        errordlg('Erreur frequence echantillonnage','Program error');
                    end
                    if ((rep<0)|(rep>1))
                        errordlg('Erreur repliement','Program error');
                    end
                end
            end
            
            if (out==0)
            
                %Cas filtre anti-repliement
                if rep
                    ye=resample(y,Fe,Fs);
                % Sans filtre anti-repliement
                else
                    ye=downsample(y,floor(Fs/Fe));
                end

                %Affichage/Ecoute resultat
                retour=0;
                while (~retour)
                    choix=menu('Echantillonnage','Visualiser','Ecouter','Retour');
                    switch choix
                        case 1
                            figure(10)
                            s=subplot(2,1,1);
                            
                            Y = fft(y)/length(y);
                            f = Fs*linspace(0,1,length(y));
                            plot(f,db(abs(Y))) 
                            title(s,['Spectre signal original (Fs=',num2str(Fs),' Hz)']);
                            xlabel('Frequency (Hz)')
                            ylabel('20log(|Y(f)|)')
                            s=subplot(2,1,2);
                            Y = fft(ye)/length(ye);
                            f = Fe*linspace(0,1,length(ye));
                            plot(f,db(abs(Y))) 
                            title(s,['Spectre signal echantillonne (Fs=',num2str(Fe),' Hz)']);
                            xlabel('Frequency (Hz)')
                            ylabel('20log(|Y(f)|)')
                        case 2
                            sound(ye,Fe);
                        otherwise
                            retour=1;
                            close all;
                    end
                end
            end
            
            cas='menu';
            
            
        % Quantification
            
        case 'quant'
            retour=0;
            
            if exist('ye')
                yo=ye;
                Fo=Fe;
            else
                yo=y;
                Fo=Fs;
            end
            
            while (~retour)
                choix=menu('Quantification','Afficher signal','Uniforme','Non-Uniforme','Retour');
                
                switch choix
                    
                    % Affichage signal original et distribution
                    case 1
                        figure(10)
                        s=subplot(1,2,1);
                        t=(0:length(yo)-1)*1/Fo;
                        plot(t,y)
                        title(s,['Signal original (Fs=',num2str(Fo),' Hz)']);
                        s=subplot(1,2,2);
                        hist(yo,100)
                        title(s,['Distribution']);
                    
                    % Quantification Uniforme
                    case 2
                        N=0;
                        out=0;
                        A=0;
                        while (((N<=0)|(A<=0))&(out==0))
                            % Reglage dynamique et nb echantillons
                            prompt = {'Nombre d echantillons:','Dynamique:'};
                            dlg_title = 'Quantification Uniforme';
                            num_lines = 1;
                            def = {'8','1'};
                            answer = inputdlg(prompt,dlg_title,num_lines,def);
                            if isempty(answer)
                                out=1;
                            else
                                N=str2num(answer{1});
                                A=str2num(answer{2});
                                if (N<=0)
                                    errordlg('Erreur nombre echantillons','Program error');
                                end
                                if (A<=0)
                                    errordlg('Erreur dynamique','Program error');
                                end
                            end
                            
                        end
                        
                        if (out==0)
                            
                            if N==3
                                N=N+1;
                            end
                            
                            p=rem(N,2);
                            q=A/N;
                            n=floor(N/2);

                            if p
                                partx=-(n+1)*q/2:q:(n+1)*q/2;
                                party= -n*q:q:n*q;
                            else
                                partx=-(n-1)*q:q:(n-1)*q;
                                party=-(N-1)*q/2:q:(N-1)*q/2;
                            end

                            indx = quantiz(yo, partx);

                            yq=party(indx+1);
                            
                            retour2=0;
                            % Affichage/Ecoute du resultat
                            while (~retour2)
                                choix=menu('Quantification','Visualiser','Ecouter','Erreur','Retour');
                                switch choix
                                    
                                    case 1
                                        figure(10)
                                        s=subplot(2,1,1);
                                        t=(0:length(yo)-1)*1/Fo;
                                        plot(t,yo)
                                        title(s,['Signal original']);
                                        s=subplot(2,1,2);
                                        t=(0:length(yq)-1)*1/Fo;
                                        plot(t,yq)
                                        err=sqrt(sum((yq-yo').^2));
                                        title(s,['Signal quantifie (erreur=',num2str(err),')']);
                                        
                                    case 2
                                        sound(yq,Fo);
                                        
                                    % Affichage distribution erreur
                                    case 3
                                        err=yq-yo';
                                        figure(10)
                                        hist(err,100);
                                        title('Histogramme erreurs');
                                        
                                    otherwise
                                        retour2=1;
                                        close all;
                                end
                            end
                            
                        end
                        
                        
                    % Quantif non-uniforme
                    case 3
                        
                        N=0;
                        out=0;
                        A=0;
                        while (((N<=0)|(A<=0))&(out==0))
                            
                            %Reglage dynamique et nb echantillons
                            prompt = {'Nombre d echantillons (2^N):','Dynamique:'};
                            dlg_title = 'Quantification Non-Uniforme';
                            num_lines = 1;
                            def = {'8','1'};
                            answer = inputdlg(prompt,dlg_title,num_lines,def);
                            if isempty(answer)
                                out=1;
                            else
                                N=str2num(answer{1});
                                A=str2num(answer{2});
                                if (N<=0)
                                    errordlg('Erreur nombre echantillons','Program error');
                                end
                                if (A<=0)
                                    errordlg('Erreur dynamique','Program error');
                                end
                            end
                            
                        end
                        
                        if (out==0)
                            
                            y2 = yo./(0.5*A);
                            ind1 = find(y2>1);
                            ind2 = find(y2<-1);
                            y2(ind1) = ones(1,length(ind1));
                            y2(ind2) = -ones(1,length(ind2));
                            ymu = lin2mu(y2);
                            
%                             % Ech non uniforme pour N<8bits (experimental - NOT WORKING)
%                             if (N<8)
%                                 k=(2^8-2^N)/2;
%                                 
%                                 ind1=find((ymu>=128)&(ymu<(128+k)));
%                                 ind2=find((ymu>=128-k)&(ymu<128));
%                                 ymu(ind1)=ymu(128+k);
%                                 ymu(find(ymu>=128))=ymu(find(ymu>=128))-k;
%                                 ymu(ind2)=ymu(128-k-1);
%                                 ymu(find(ymu<128))=ymu(find(ymu<128))+k;
%                                 
%                                 
%                             end


%                             % Ech non uniforme pour N<8bits (experimental - NOT WORKING)
%                             if (N<8)
%                                 k=(2^8-2^N)/2;
%                                 
%                                 for i=1:length(ymu)
%                                     if rem(ymu(i),k)
%                                         ymu(i)=ymu(i)-rem(ymu(i),k);
%                                     end
%                                 end
%                                 
%                             end
                            
                            yq = mu2lin(ymu).*(0.5*A);
                                
                            
                            retour2=0;
                            % Affichage/Ecoute du r??sultat
                            while (~retour2)
                                choix=menu('Quantification','Visualiser','Ecouter','Erreur','Retour');
                                switch choix
                                    
                                    % Affichage des signaux
                                    case 1
                                        figure(10)
                                        s=subplot(2,1,1);
                                        t=(0:length(yo)-1)*1/Fo;
                                        plot(t,yo)
                                        title(s,['Signal original']);
                                        s=subplot(2,1,2);
                                        t=(0:length(yq)-1)*1/Fo;
                                        plot(t,yq)
                                        err=sqrt(sum((yq-yo).^2));
                                        title(s,['Signal quantifie (erreur=',num2str(err),')']);
                                    
                                    % Ecoute resultat
                                    case 2
                                        sound(yq,Fo);
                                    
                                    % Affichage distribution erreur
                                    case 3
                                        err=yq-yo;
                                        figure(10)
                                        hist(err,100);
                                        title('Histogramme erreurs');
                                        
                                    otherwise
                                        retour2=1;
                                        close all;
                                end
                            end
                            
                        end
                        
                    % Retour menu    
                    otherwise
                        retour=1;
                        cas = 'menu';
                end
                
            end
                        
        % Cas erreur     
        otherwise
            errordlg('Cas non valide','Program error');
    end
    
end

    
    
