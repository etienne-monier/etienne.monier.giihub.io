function out=quantim(X,part)

[h,w]=size(X);

out=zeros(h,w);

for k=1:length(part)
    out=out+(X>part(k));
end

end