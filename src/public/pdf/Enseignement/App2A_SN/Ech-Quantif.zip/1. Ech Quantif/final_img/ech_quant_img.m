%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Echantillonnage et quantification sur image
% A. Picot - Fevrier 2015
%
% Fichier: Lena.gif
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all

cas='menu';
ok=1;
choix=0;

% Loading image
[X,map]=imread('lena2.gif');
[H,W]=size(X);


while (ok)
    
    switch cas
        %Menu principal
        case 'menu'

            choix=menu({'Echantillonnage - Quantification','Traitement d image'},...
                'Visualiser','Histogramme','Echantillonner','Quantifier','Quitter');
            switch choix
                case 1
                    cas='visu';
                case 2
                    cas='hist';
                case 3
                    cas='ech';
                case 4
                    cas='quant';
                otherwise
                    ok=0;
                    close all
            end
            
        % Ecoute    
        case 'visu'
            figure(10);
            imshow(X);
            cas='menu';
            
        % Echantillonnage    
        case 'ech'
            
            ech=1;
            out=0;
            
            while ((ech<=1)&(out==0))
                %Menu
                prompt = {'Nombre de pixels (<512):'};
                dlg_title = 'Echantillonnage';
                num_lines = 1;
                def = {'256'};
                answer = inputdlg(prompt,dlg_title,num_lines,def);
                if isempty(answer)
                    out=1;
                else
                    ech=str2num(answer{1});
                    if (ech>512)
                        errordlg('Erreur rapport echantillonnage','Program error');
                    end
                end
            end
            
            if (out==0)
                
                %Calcul nouvelle taille
                S=ech;
                Xe=imresize(X,[S,S]);
                %Affichage
                figure(10)
                s=subplot(1,2,1);
                imshow(X)
                title(s,'Image originale');
                s=subplot(1,2,2);
                imshow(Xe);
                title(s,['Image echantillonnee (Nombre pixels=',num2str(ech),')']);
                
            end
               
            
            cas='menu';
            
            
        % Quantification
            
        case 'quant'
            retour=0;
            
            if exist('Xe')
                Xo=Xe;
            else
                Xo=X;
            end
            
            
            N=0;
            out=0;
            A=0;
            while (((N<=0)|(A<=0))&(out==0))
                % Reglage dynamique et nb echantillons
                prompt = {'Nombre d echantillons:','Dynamique - min:','Dynamique - max:'};
                dlg_title = 'Quantification Uniforme';
                num_lines = 1;
                def = {'8','0','255'};
                answer = inputdlg(prompt,dlg_title,num_lines,def);
                if isempty(answer)
                    out=1;
                else
                    N=str2num(answer{1});
                    Amin=str2num(answer{2});
                    Amax=str2num(answer{3});
                    A=Amax-Amin+1;
                    if (N<=0)
                        errordlg('Erreur nombre echantillons','Program error');
                    end
                    if (A<1)
                        errordlg('Erreur dynamique','Program error');
                    end
                end

            end

            if (out==0)
                
                if N==3
                    N=N+1;
                end

                p=rem(N,2);
                q=A/N;
                n=floor(N/2);

                if p
                    partx=-(n+1)*q/2:q:(n+1)*q/2;
                    party= -n*q:q:n*q;
                else
                    partx=-(n-1)*q:q:(n-1)*q;
                    party=-(N-1)*q/2:q:(N-1)*q/2;
                end

                a=quantim(Xo,partx+128);

                Xq=uint8(abs(party(a+1)+(Amax+Amin)/2));

                %Affichage
                figure(10)
                s=subplot(1,2,1);
                imshow(Xo)
                title(s,'Image originale');
                s=subplot(1,2,2);
                imshow(Xq);
                title(s,['Image quantifiee (',num2str(N),' echantillons)']);
%                 err=sqrt(sum(sum((Xo-Xq).^2)));
%                 title(s,{['Image quantifiee (',num2str(N),' echantillons)'],...
%                     ['Erreur=',num2str(err)]});
                            
                
            end
            
            cas='menu';
        
        %Affichage histogramme
        case 'hist'
            figure(10)
            imhist(X)
            title('histogramme')
            cas='menu'
            
            
        % Cas erreur     
        otherwise
            errordlg('Cas non valide','Program error');
    end
    
end

    
    
